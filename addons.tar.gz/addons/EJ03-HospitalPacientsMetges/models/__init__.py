# -*- coding: utf-8 -*-
from . import patient
from . import doctor
from . import medical_visit
