# -*- coding: utf-8 -*-
from . import ciclo
from . import modulo
from . import alumno
from . import profesor

