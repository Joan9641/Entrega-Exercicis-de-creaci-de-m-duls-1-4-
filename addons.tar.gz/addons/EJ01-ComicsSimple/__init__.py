# -*- coding: utf-8 -*-
# Indicamos que se importe el contenido Python de la carpeta "models" y "controllers"
# Aunque en este ejemplo, la carpeta "controllers" esta vacia
from . import models
from . import controllers